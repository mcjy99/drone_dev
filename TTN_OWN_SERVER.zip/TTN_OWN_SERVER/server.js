var express = require("express");
var app = express();
app.use(express.static("public")); //Procedure to set public folder contain process files (css,image,.js,..)
app.set('view engine', 'ejs'); // Use ejs instead of html
app.set("views","./views"); // view folder contain .ejs files

// Parse URL-encoded bodies (as sent by HTML forms)
const bodyParser = require('body-parser')
app.use(bodyParser.urlencoded({extended: true}))

// Create server
var server = require("http").Server(app); 
var io = require("socket.io")(server); 
server.listen(process.env.PORT || 3000, () => { 
   console.log('listening on *:3000');
});

// MQTT setup
var mqtt = require('mqtt');
var options = {
    port: 1883,
    clientId: 'mqttjs_' + Math.random().toString(16).substr(2, 8),
    username: 'wisblock-rak@ttn',
    password: 'NNSXS.O6PB56L5SOSCMGENHXACDWTUUGKR3TFC6YVFJEI.WKGTAYKEYLG4475JXDV2KSP6MIYURCFB2OS44WS53EBWDX74DYPA',
    keepalive: 60,
    reconnectPeriod: 1000,
    protocolId: 'MQIsdp',
    protocolVersion: 3,
    clean: true,
    encoding: 'utf8'
};
var client = mqtt.connect('https://au1.cloud.thethings.network',options);

// Global variable to save data
var globalMQTT = 0;


// SOCKET
io.on("connection", function(socket)
{
  console.log("Client connected: " + socket.id);

  socket.on("disconnect", function() {
    console.log(socket.id + " disconnected");
  });

  socket.on("REQUEST_GET_DATA", function() {
    socket.emit("SEND_DATA",globalMQTT);
  });

  function intervalFunc() {
    socket.emit("SEND_DATA", globalMQTT);
  }
  setInterval(intervalFunc, 2000);
});


// MQTT setup
client.on('connect', function() {
    console.log('Client connected to TTN')
    client.subscribe('#')
});

client.on('error', function(err) {
    console.log(err);
});

client.on('message', function(topic, message) {
  var getDataFromTTN = JSON.parse(message);
  // Decode base64 payload to hexadecimal
  var base64Payload = getDataFromTTN.uplink_message.frm_payload;
  var hexPayload = Buffer.from(base64Payload, 'base64').toString('hex');
  // Extract SNR and RSSI from rx_metadata
  var rxMetadata = getDataFromTTN.uplink_message.rx_metadata[0]; 
  var snr = rxMetadata.snr; // SNR
  var rssi = rxMetadata.rssi; // RSSI

  console.log("Data from TTN (hexadecimal): ", hexPayload);
  console.log("SNR: ", snr);
  console.log("RSSI: ", rssi);
  
  // Assign hexPayload to globalMQTT if needed
  globalMQTT = {
    "hexPayload": hexPayload,
    "snr": snr,
    "rssi": rssi
  };
});



// Setup load ejs file to display on Browsers
app.get('/lora',function(req,res){
   res.render("dashboard");
});