#include <stdio.h>

#include "edge-impulse-sdk/classifier/ei_run_classifier.h"

// Callback function declaration
static int get_signal_data(size_t offset, size_t length, float *out_ptr);

// Raw features copied from test sample (Edge Impulse > Model testing)
static float input_buf[] = {
    -2.9800, 0.7900, 10.2100, -2.0400, 0.4700, 9.4200, 0.0000, 0.4700, 9.8900, 0.3100, 0.4700, 10.9900, 0.3100, 0.0000, 10.2100, 1.1000, -0.1600, 8.1700, 1.8800, -0.6300, 7.5400, 2.6700, -0.7900, 8.3200, 1.8800, -0.4700, 9.8900, 2.2000, -0.3100, 9.5800, 2.2000, -0.6300, 9.5800, 2.5100, -0.6300, 9.1100, 2.9800, -0.4700, 9.1100, 3.6100, -0.1600, 9.8900, 3.6100, 0.0000, 10.6800, 3.9300, -0.4700, 9.7400, 3.1400, -0.7900, 8.3200, 2.9800, -0.7900, 8.0100, 2.6700, -1.1000, 9.1100, 2.8300, -0.4700, 9.7400, 2.0400, -0.1600, 10.0500, 2.2000, -0.3100, 10.3600, 1.7300, -0.3100, 10.2100, 1.2600, -0.4700, 9.7400, 1.1000, -0.4700, 9.7400, 1.2600, -0.4700, 9.8900, 0.6300, 0.1600, 9.7400, -0.1600, 0.3100, 9.5800, -0.1600, 0.7900, 9.4200, -0.1600, 1.4100, 9.7400, -0.3100, 1.2600, 9.5800, -0.6300, 0.4700, 9.2700, -0.6300, 0.3100, 8.9500, -0.6300, 0.0000, 9.1100, -0.9400, 0.3100, 9.7400, -0.9400, 0.6300, 8.9500, -1.2600, -1.2600, 8.6400, -1.8800, -1.4100, 8.6400, -2.0400, -1.4100, 8.7900, -2.0400, -1.8800, 8.7900, -2.2000, -2.0400, 8.9500, -2.6700, -2.0400, 9.1100, -2.9800, -1.8800, 9.2700, -2.9800, -2.8300, 9.8900, -3.1400, -3.4500, 9.8900, -3.4500, -3.3000, 10.0500, -3.6100, -2.8300, 10.8400, -3.4500, -3.1400, 10.2100, -2.8300, -2.2000, 9.5800, -2.5100, -1.5700, 8.7900, -2.3600, -1.4100, 8.0100, -2.2000, -0.9400, 8.6400, -1.7300, -0.9400, 8.9500, -1.1000, 0.0000, 8.4800, -0.4700, 1.1000, 8.7900, -0.3100, 1.2600, 9.8900, -0.1600, 0.7900, 10.0500, -0.1600, 0.3100, 9.5800, -0.1600, -0.1600, 10.0500, 0.3100, 1.1000, 10.6800, 1.2600, 0.9400, 11.1500, 1.1000, 0.4700, 10.6800, 0.7900, -0.4700, 10.6800, 1.2600, -0.4700, 10.6800, 1.4100, -0.6300, 10.2100, 2.2000, -0.4700, 10.3600, 2.2000, -0.4700, 10.0500, 1.8800, -0.6300, 8.4800, 1.8800, -0.6300, 7.3800, 2.0400, -0.3100, 6.9100, 0.1600, -0.7900, 8.7900, -1.8800, -0.1600, 10.9900, -2.8300, -0.3100, 10.6800, -2.5100, -0.1600, 8.4800, 0.0000, 0.0000, 9.1100, 0.9400, 0.6300, 9.8900, 0.1600, 0.7900, 10.6800, -1.1000, 0.6300, 10.6800, -2.0400, 0.6300, 9.8900, -2.2000, 0.4700, 9.4200, -1.5700, 0.0000, 9.2700, -0.4700, -0.3100, 8.6400, 0.7900, -0.1600, 8.7900, 1.4100, 0.3100, 9.4200, 0.7900, 0.7900, 10.0500, 0.9400, 0.6300, 9.4200, 1.2600, 0.6300, 9.4200, 1.4100, 0.6300, 9.2700, 1.2600, 0.7900, 9.5800, 1.4100, 0.6300, 9.4200, 2.0400, 0.4700, 9.1100, 2.0400, 0.7900, 9.5800, 2.0400, 0.7900, 9.4200, 2.0400, 1.1000, 10.0500
};

int main(int argc, char **argv) {
    
    signal_t signal;            // Wrapper for raw input buffer
    ei_impulse_result_t result; // Used to store inference output
    EI_IMPULSE_ERROR res;       // Return code from inference

    // Calculate the length of the buffer
    size_t buf_len = sizeof(input_buf) / sizeof(input_buf[0]);

    // Make sure that the length of the buffer matches expected input length
    if (buf_len != EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE) {
        printf("ERROR: The size of the input buffer is not correct.\r\n");
        printf("Expected %d items, but got %d\r\n", 
                EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE, 
                (int)buf_len);
        return 1;
    }

    // Assign callback function to fill buffer used for preprocessing/inference
    signal.total_length = EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE;
    signal.get_data = &get_signal_data;

    // Perform DSP pre-processing and inference
    res = run_classifier(&signal, &result, false);

    // Print return code and how long it took to perform inference
    printf("run_classifier returned: %d\r\n", res);
    printf("Timing: DSP %d ms, inference %d ms, anomaly %d ms\r\n", 
            result.timing.dsp, 
            result.timing.classification, 
            result.timing.anomaly);

    // Print the prediction results (object detection)
#if EI_CLASSIFIER_OBJECT_DETECTION == 1
    printf("Object detection bounding boxes:\r\n");
    for (uint32_t i = 0; i < EI_CLASSIFIER_OBJECT_DETECTION_COUNT; i++) {
        ei_impulse_result_bounding_box_t bb = result.bounding_boxes[i];
        if (bb.value == 0) {
            continue;
        }
        printf("  %s (%f) [ x: %u, y: %u, width: %u, height: %u ]\r\n", 
                bb.label, 
                bb.value, 
                bb.x, 
                bb.y, 
                bb.width, 
                bb.height);
    }

    // Print the prediction results (classification)
#else
    printf("Predictions:\r\n");
    for (uint16_t i = 0; i < EI_CLASSIFIER_LABEL_COUNT; i++) {
        printf("  %s: ", ei_classifier_inferencing_categories[i]);
        printf("%.5f\r\n", result.classification[i].value);
    }
#endif

    // Print anomaly result (if it exists)
#if EI_CLASSIFIER_HAS_ANOMALY == 1
    printf("Anomaly prediction: %.3f\r\n", result.anomaly);
#endif

    return 0;
}

// Callback: fill a section of the out_ptr buffer when requested
static int get_signal_data(size_t offset, size_t length, float *out_ptr) {
    for (size_t i = 0; i < length; i++) {
        out_ptr[i] = (input_buf + offset)[i];
    }

    return EIDSP_OK;
}